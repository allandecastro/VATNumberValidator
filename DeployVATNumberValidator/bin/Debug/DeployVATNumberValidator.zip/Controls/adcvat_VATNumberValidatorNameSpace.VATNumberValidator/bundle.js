var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./VATNumberValidator/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./VATNumberValidator/index.ts":
/*!*************************************!*\
  !*** ./VATNumberValidator/index.ts ***!
  \*************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\n\nvar VATNumberValidator =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function VATNumberValidator() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  VATNumberValidator.prototype.init = function (context, notifyOutputChanged, state, container) {\n    // Add control initialization code\n    this._context = context;\n    this._container = container;\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._vatNumberChanged = this.vatNumberChanged.bind(this);\n    this._vatNumber = this._context.parameters.vatNumberfield == null || this._context.parameters.vatNumberfield.raw == null ? \"\" : this._context.parameters.vatNumberfield.raw.trim();\n    this._companyName = this._context.parameters.companyName == null || this._context.parameters.companyName.raw == null ? \"\" : this._context.parameters.companyName.raw;\n    this._companyAddress = this._context.parameters.companyAddress == null || this._context.parameters.companyAddress.raw == null ? \"\" : this._context.parameters.companyAddress.raw;\n    this._displayDialog = this._context.parameters.displayDialog == null || this._context.parameters.displayDialog.raw == null ? \"\" : this._context.parameters.displayDialog.raw;\n    this._container = document.createElement(\"div\");\n    container.appendChild(this._container);\n    this._vatNumberElement = document.createElement(\"input\");\n\n    this._vatNumberElement.setAttribute(\"type\", \"text\");\n\n    if (this._vatNumber.length > 0) this._vatNumberElement.setAttribute(\"title\", this._vatNumber);else this._vatNumberElement.setAttribute(\"title\", \"Select to enter data\");\n\n    this._vatNumberElement.setAttribute(\"class\", \"pcfvatinputcontrol\");\n\n    this._vatNumberElement.addEventListener(\"change\", this._vatNumberChanged);\n\n    this._vatNumberTypeElement = document.createElement(\"img\");\n\n    this._vatNumberTypeElement.setAttribute(\"class\", \"pcfvatimagecontrol\");\n\n    this._vatNumberTypeElement.setAttribute(\"height\", \"24px\");\n\n    this._container.appendChild(this._vatNumberElement);\n\n    this._container.appendChild(this._vatNumberTypeElement);\n\n    this.SecurityEnablement(this._vatNumberElement);\n  };\n  /**\r\n  * Called when a change is detected in the phone number input.\r\n  */\n\n\n  VATNumberValidator.prototype.vatNumberChanged = function () {\n    this._vatNumberElement.value = this._vatNumberElement.value.trim().replace(\" \", \"\").toUpperCase();\n    this.CheckVatNumber();\n\n    if (this._vatNumber != this._vatNumberElement.value) {\n      this._vatNumber = this._vatNumberElement.value;\n\n      this._vatNumberElement.setAttribute(\"title\", this._vatNumber);\n\n      this._notifyOutputChanged();\n    }\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  VATNumberValidator.prototype.updateView = function (context) {\n    var visible = this._context.mode.isVisible;\n\n    if (visible) {\n      this._vatNumber = this._context.parameters.vatNumberfield == null || this._context.parameters.vatNumberfield.raw == null ? \"\" : this._context.parameters.vatNumberfield.raw.trim();\n\n      if (this._vatNumber != null && this._vatNumber.length > 0 && this._vatNumber != this._vatNumberElement.value) {\n        this._vatNumberElement.value = this._vatNumber;\n        this.CheckVatNumber();\n      }\n    }\n  };\n  /**\r\n   * Used to implement the security model about the targeted field\r\n   * @param _vatNumberElement The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   */\n\n\n  VATNumberValidator.prototype.SecurityEnablement = function (_vatNumberElement) {\n    var readOnly = this._context.mode.isControlDisabled; // If the form is diabled because it is inactive or the user doesn't have access isControlDisabled is set to true\n    // When a field has FLS enabled, the security property on the attribute parameter is set\n\n    var masked = false;\n\n    if (this._context.parameters.vatNumberfield.security) {\n      readOnly = readOnly || !this._context.parameters.vatNumberfield.security.editable;\n      masked = !this._context.parameters.vatNumberfield.security.readable;\n    }\n\n    if (masked) this._vatNumberElement.setAttribute(\"placeholder\", \"*******\");else this._vatNumberElement.setAttribute(\"placeholder\", \"Insert a VAT Number..\");\n    if (readOnly) this._vatNumberElement.readOnly = true;else this._vatNumberElement.readOnly = false;\n  };\n  /**\r\n   * Used to query the SOAP services and set the result to the appropriate fields.\r\n   */\n\n\n  VATNumberValidator.prototype.CheckVatNumber = function () {\n    this.findAndSetImage(\"loading\", \"gif\");\n\n    if (this._vatNumberElement.value.length > 0) {\n      var xmlhttp = new XMLHttpRequest();\n      xmlhttp.open('POST', 'https://cors-anywhere.herokuapp.com/http://ec.europa.eu/taxation_customs/vies/services/checkVatService', false); // build SOAP request\n\n      var soadpRequest = \"<?xml version='1.0' encoding='UTF-8'?>\" + \"<SOAP-ENV:Envelope xmlns:ns0='urn:ec.europa.eu:taxud:vies:services:checkVat:types'\" + \" xmlns:ns1='http://schemas.xmlsoap.org/soap/envelope/'\" + \" xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance'\" + \" xmlns:SOAP-ENV='http://schemas.xmlsoap.org/soap/envelope/'>\" + \"<SOAP-ENV:Header/><ns1:Body><ns0:checkVat>\" + \"<ns0:countryCode>\" + this._vatNumberElement.value.slice(0, 2).toUpperCase() + \"</ns0:countryCode>\" + \"<ns0:vatNumber>\" + this._vatNumberElement.value.slice(2) + \"</ns0:vatNumber>\" + \"</ns0:checkVat></ns1:Body></SOAP-ENV:Envelope>\";\n      var isValid = false;\n\n      var _this = this;\n\n      xmlhttp.onreadystatechange = function () {\n        if (xmlhttp.readyState == 4) {\n          if (xmlhttp.status == 200) {\n            var parser, xmlDoc;\n            parser = new DOMParser();\n            xmlDoc = parser.parseFromString(xmlhttp.responseText, \"text/xml\");\n\n            if (xmlDoc.getElementsByTagName(\"valid\")[0] != undefined && xmlDoc.getElementsByTagName(\"valid\")[0].childNodes[0].nodeValue === \"true\") {\n              _this._isValid = true;\n              if (xmlDoc.getElementsByTagName(\"name\")[0] != undefined) _this._companyName = xmlDoc.getElementsByTagName(\"name\")[0].childNodes[0].nodeValue == null || xmlDoc.getElementsByTagName(\"name\")[0].childNodes[0].nodeValue == undefined ? \"\" : xmlDoc.getElementsByTagName(\"name\")[0].childNodes[0].nodeValue;\n              if (xmlDoc.getElementsByTagName(\"address\")[0] != undefined) _this._companyAddress = xmlDoc.getElementsByTagName(\"address\")[0].childNodes[0].nodeValue == null || xmlDoc.getElementsByTagName(\"address\")[0].childNodes[0].nodeValue == undefined ? \"\" : xmlDoc.getElementsByTagName(\"address\")[0].childNodes[0].nodeValue;\n\n              _this.findAndSetImage(_this._vatNumberElement.value.slice(0, 2).toLowerCase(), \"png\");\n            } else {\n              _this._isValid = false;\n              if (_this._displayDialog === \"Both\" || _this._displayDialog === \"NotFound\") _this._context.navigation.openAlertDialog({\n                text: \"No result found for the following VAT Number: \" + _this._vatNumberElement.value\n              });\n\n              _this.findAndSetImage(\"warning\", \"png\");\n            }\n          } else {\n            if (_this._displayDialog === \"Both\" || _this._displayDialog === \"ApiError\") _this._context.navigation.openAlertDialog({\n              text: \"Problem with the remote service, status: \" + xmlhttp.status\n            });\n\n            _this.findAndSetImage(\"warning\", \"png\");\n          }\n        }\n      }; // Send the POST request\n\n\n      xmlhttp.setRequestHeader('Content-Type', 'text/xml');\n      xmlhttp.send(soadpRequest);\n    }\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  VATNumberValidator.prototype.getOutputs = function () {\n    return {\n      vatNumberfield: this._vatNumber,\n      isVatNumberValid: this._isValid,\n      companyName: this._companyName,\n      companyAddress: this._companyAddress\n    };\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  VATNumberValidator.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n  /**\r\n  * Called when a change is detected in the phone number input\r\n  * @param imageName Name of the image to retrieve\r\n  */\n\n\n  VATNumberValidator.prototype.findAndSetImage = function (imageName, imageExtension) {\n    var _this_1 = this;\n\n    this._context.resources.getResource(\"img/\" + imageName + \".\" + imageExtension, function (data) {\n      _this_1._vatNumberTypeElement.setAttribute(\"src\", _this_1.generateImageSrcUrl(\".\" + imageExtension, data));\n    }, function () {\n      console.log('Error when downloading ' + imageName + '.' + imageExtension + ' image.');\n    });\n  };\n  /**\r\n  * Called when a change is detected in the phone number input\r\n  * @param filetype Name of the image extension\r\n  * @param fileContent Base64 image content\r\n  */\n\n\n  VATNumberValidator.prototype.generateImageSrcUrl = function (fileType, fileContent) {\n    return \"data:image/\" + fileType + \";base64,\" + fileContent;\n  };\n\n  return VATNumberValidator;\n}();\n\nexports.VATNumberValidator = VATNumberValidator;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./VATNumberValidator/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('VATNumberValidatorNameSpace.VATNumberValidator', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.VATNumberValidator);
} else {
	var VATNumberValidatorNameSpace = VATNumberValidatorNameSpace || {};
	VATNumberValidatorNameSpace.VATNumberValidator = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.VATNumberValidator;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}